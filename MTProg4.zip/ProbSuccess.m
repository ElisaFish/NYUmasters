function PS = ProbSuccess(ProbSuc, ProbPosSuc, ProbPosFail, NPos, NNeg)
    %ProbSuc = P(Success).
    %ProbPosSuc = P(For | Success).
    %ProbPosFail = P(For | Fail).
    %NPos = the number of reviewers who have given a positive review. 
    %NNeg = the number of reviewers who have given a negative review.
    
    PS = ProbPosSuc^NPos * (1-ProbPosSuc)^NNeg * ProbSuc / (ProbPosSuc^NPos * (1-ProbPosSuc)^NNeg * ProbSuc + ProbPosFail^NPos * (1-ProbPosFail)^NNeg * (1-ProbSuc)); 
end