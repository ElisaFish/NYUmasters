function Exp = PubValue2(ValueSuc, ValueFail, Fee, ProbSuc, ProbPosSuc, ProbPosFail, N)
    Exp = 0;
    for npos = 0:N
        P_npos_suc = nchoosek(N, npos) * ProbPosSuc^npos *(1-ProbPosSuc)^(N-npos);
        P_npos_fail = nchoosek(N, npos) * ProbPosFail^npos * (1-ProbPosFail)^(N-npos);
        P_pos = P_npos_suc * ProbSuc + P_npos_fail * (1-ProbSuc);
        [choice, Exp_npos] = PubValue1(ValueSuc, ValueFail, Fee, ProbSuc, ProbPosSuc, ProbPosFail, npos, N-npos);
        Exp = Exp + P_pos * Exp_npos;
    end
end