function [ChooseToPub, Exp] = PubValue1(ValueSuc, ValueFail, Fee, ProbSuc, ProbPosSuc, ProbPosFail, NPos, NNeg)
    %ValueSuc = Dollar profit if the book succeeds.
    %CostFail = Cost if the book fails (a positive number).
    %Fee = Cost of hiring a reviewer (a positive number).
    
    PS = ProbSuccess(ProbSuc, ProbPosSuc, ProbPosFail, NPos, NNeg);
    Exp_Pub = PS * (ValueSuc - (NPos + NNeg) * Fee) - (1-PS) * (ValueFail + (NPos + NNeg) * Fee);
    Exp_Reject = - (NPos + NNeg) * Fee;
    if Exp_Pub > Exp_Reject
        ChooseToPub = true;
        Exp = Exp_Pub;
    else
        ChooseToPub = false;
        Exp = Exp_Reject;
    end
end