function [Opt_N, Exp] = OptimalN(ValueSuc, ValueFail, Fee, ProbSuc, ProbPosSuc, ProbPosFail)
    Opt_N = 0;
    Exp = 0;
    for N = 0:(ProbSuc * ValueSuc / Fee)
        Exp_temp = PubValue2(ValueSuc, ValueFail, Fee, ProbSuc, ProbPosSuc, ProbPosFail, N);
        if Exp_temp > Exp
            Opt_N = N;
            Exp = Exp_temp;
        end
    end
end