function SD = Stationary(T)
    nstates = length(T);
    v = sparse(nstates, 1);
    %v(start) = 1;
    v(1) = 1;
    v_next = sparse(nstates, 1);
    while true
        v_next = T * v;
        %if round(v,5) == round(v_next,5)
        if v == v_next
            break
        end
        v = v_next;
    end
    SD = v_next;
end