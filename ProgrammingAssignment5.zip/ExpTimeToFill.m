function Exp = ExpTimeToFill(T, EPS)
    nstates = length(T);
    U = T;
    U(:,nstates) = zeros(nstates,1);
    U(nstates,nstates) = 1;
    S0 = sparse(nstates,1);
    S0(1) = 1;
    Exp = 0;
    P_I_prev = 0;
    P_I = 0;
    i=1;
    while (1 - P_I) * i >= EPS
        S = U * S0;
        S0 = S;
        
        P_I = S(nstates);
        Prob = P_I - P_I_prev;
        Exp = Exp + i * Prob;
 
        i = i+1;
        P_I_prev = P_I;
    end
end