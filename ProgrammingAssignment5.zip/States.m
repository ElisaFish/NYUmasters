function states = States(K)
    ntypes = length(K);
    nstates = 1 + K(1);
    for i = 2:ntypes
        nstates = nstates * (1 + K(i));
    end
    states = zeros(ntypes,nstates);
    counters = zeros(ntypes,1);
    for col = 1:nstates
        states(:,col) = transpose(counters);
        counters = updateCounters(K, ntypes, counters);
    end
end

function counters = updateCounters(K, ntypes, counters)
    for coin = ntypes:-1:1
        if coin == ntypes | counters(coin+1:ntypes) == transpose(zeros(ntypes-coin))
            if counters(coin) < K(coin)
                counters(coin) = counters(coin) + 1;
            else
                counters(coin) = 0;
            end
        end
    end
end