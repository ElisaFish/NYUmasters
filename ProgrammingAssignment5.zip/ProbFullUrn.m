function P_I = ProbFullUrn(T,N)
    nstates = length(T);
    U = T;
    U(:,nstates) = zeros(nstates,1);
    U(nstates,nstates) = 1;
    S0 = sparse(nstates,1);
    S0(1) = 1;
    for i = 1:N
        S = U * S0;
        P_I(i) = S(nstates);
        S0 = S;
    end
end