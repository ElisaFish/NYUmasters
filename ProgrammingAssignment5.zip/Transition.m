function transition_matrix = Transition(S,H)
    nstates = length(S);
    ntypes = length(H);
    ncoins(1:ntypes) = transpose(S(:,nstates));
    transition_matrix = zeros(nstates,nstates);
    for from = 1:nstates
        outside = zeros(1,ntypes);
        for type = 1:ntypes
            outside(type) = ncoins(type) - S(type,from);
        end
        for to = 1:nstates
            if from == 1 || from == nstates
                P_area = 1;
            else
                P_area = 1/2;
            end
            
            if from == to
                % Case where you stay in the same state
                transition_matrix(to, from) = 0;
                if from ~= 1
                   for type = 1:ntypes
                      P_type = S(type, from) /  sum(S(:,from));
                      P_flip = H(type);
                      transition_matrix(to, from) = transition_matrix(to,from) + P_area * P_type * P_flip;
                   end
                end
                if from ~= nstates
                   for type = 1:ntypes
                      P_type = outside(type) / sum(outside);
                      P_flip = 1 - H(type);
                      transition_matrix(to,from) = transition_matrix(to,from) + P_area * P_type * P_flip;
                   end
                end
                continue
            end
            
            diff = S(:,to) - S(:,from);
            
            if nnz(diff) > 1
                transition_matrix(to, from) = 0;
                continue
            else
                [type, one, change] = find(diff);
                if change > 1 || change < -1
                    transition_matrix(to,from) = 0;
                    continue
                elseif change == 1
                    P_type = outside(type) / sum(outside);
                    P_flip = H(type);
                elseif change == -1
                    P_type = S(type,from) / sum(S(:,from));
                    P_flip = 1 - H(type);
                end
                transition_matrix(to, from) = P_area * P_type * P_flip;
            end
        end
    end
end