function C = FindCharges(PA,PB,TF)
    %q = length(TF(1))
    F = reshape(TF,[],1)
    FM = ForceMatrix(PA,PB)
    C = reshape(FM,2,[]) \ F
    %for i = 1:length(PA(1))
       C = PossibleCharge(PA,PB,F);
       %for j = 1:length(PA(1))
           %if TF ~= TotalForce(PA(:,j),PB,C)
               %C = zeros(length(PA(1)))
               %break
           %end
          %return
       %end
    %end
end